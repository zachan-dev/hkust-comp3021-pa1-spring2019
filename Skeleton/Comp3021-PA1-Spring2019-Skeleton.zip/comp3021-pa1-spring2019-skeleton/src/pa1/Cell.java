package pa1;


/**
 * An immutable class that represents a cell in the grid map
 */
// TODO
